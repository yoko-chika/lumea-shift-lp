const header = document.getElementById('siteHeader');
const stickyCta = document.getElementById('stickyCta');
const fv = document.getElementById('fv');
const price = document.getElementById('price');
const finalCta = document.getElementById('finalCta');

function pinHeader() {
  header.classList.toggle('is-pinned', window.scrollY > 40);
}
window.addEventListener('scroll', pinHeader, { passive: true });
pinHeader();

let fvOut = false;
let priceIn = false;
let finalIn = false;

function updateSticky() {
  if (fvOut && !priceIn && !finalIn) {
    stickyCta.classList.add('is-show');
    stickyCta.setAttribute('aria-hidden', 'false');
  } else {
    stickyCta.classList.remove('is-show');
    stickyCta.setAttribute('aria-hidden', 'true');
  }
}

const fvObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    fvOut = !entry.isIntersecting;
    updateSticky();
  });
}, { threshold: 0 });
fvObserver.observe(fv);

const priceObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    priceIn = entry.isIntersecting;
    updateSticky();
  });
}, { threshold: 0.16 });
priceObserver.observe(price);

const finalObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    finalIn = entry.isIntersecting;
    updateSticky();
  });
}, { threshold: 0.2 });
finalObserver.observe(finalCta);

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.rv').forEach((el) => revealObserver.observe(el));

document.querySelectorAll('.faq-item button').forEach((button) => {
  button.addEventListener('click', () => {
    const item = button.closest('.faq-item');
    const isOpen = item.classList.contains('is-open');
    document.querySelectorAll('.faq-item').forEach((faq) => {
      faq.classList.remove('is-open');
      faq.querySelector('button').setAttribute('aria-expanded', 'false');
      faq.querySelector('button span').textContent = '＋';
    });
    if (!isOpen) {
      item.classList.add('is-open');
      button.setAttribute('aria-expanded', 'true');
      button.querySelector('span').textContent = '×';
    }
  });
});
